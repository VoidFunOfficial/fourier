import { defineReact, useFourierContext } from '@fourier-video/sdk';
import { HandWritingText, type HandWritingTextMotionProps } from '../../../../components/reused/HandWritingTextMotion.tsx';
import { C } from '../../../../components/design.ts';

// The SDK example owns the reveal, independent glyph motion and sampled ink filter.
// Keep its original timing: ink resolves by 78%, followed by a readable final hold.
const ink: HandWritingTextMotionProps = {
 fontSize: 204, fontWeight: 400, letterSpacing: 1, lineGap: .12,
 inkColor: C.ink, bulge: 1.15, evolutionSpeed: 1.4,
 fastBoxBlur: .55, alphaThreshold: .42,
 bevelWidth: .65, bevelDepth: .6, highlightStrength: .09,
 highlightColor: '#ffffff', highlightAngle: -38,
};

function AllIn() {
 const { width, height } = useFourierContext();
 return <div style={{ width, height, background: C.paper }}>
  <HandWritingText text={'ALL IN\nMAC mini'} props={ink}/>
 </div>;
}

export default defineReact({ name: 'MacMiniAllIn', schema: {}, component: AllIn, designPreview: () => ({ props: {}, composition: { width: 1920, height: 1080, durationSeconds: 5 } }) });
