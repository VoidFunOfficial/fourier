# Mac mini M6 — Fourier film

75 seconds · 1920 × 1080 · 60 fps · 20 independent scenes, 2–5 seconds each. No authored audio. Silver product cinematography, hand-drawn functional diagrams, flat animated artwork and restrained Apple-style typography.

The film is composed with the local Fourier SDK. The product model now comes directly from Apple’s public Mac mini AR USDZ. Blender imports its 74 meshes and original textures, then converts them to glTF without remeshing or decimation. The 50,084 source vertices, official port cavities, bottom grille and Apple mark are retained. `FourierCanvas` renders this model with absolute-time cameras and studio lighting. Binary data is split into lossless JSON chunks for the SDK source-size limit. Native `FourierMotion` drives the graphic motion. Each scene can be previewed and rendered independently; the root only orders scenes. The small motion source snapshots in `components/reused` keep the project within Fourier's standalone source boundary.

- Video: `output/Mac-mini-M6-1080p60-v3.mp4` (same bytes as `output/Mac-mini-M6-1080p60.mp4`)
- Editable project: `main.tsx`, `scenes/*`, `templates/ending/scenes/*`
- Blender source: `assets/model/mac-mini-official.blend`
- Rebuildable conversion: `scripts/import-official-model.py`
- Direction and polish: `STORYBOARD.md`
- Product facts, font and component provenance: `REFERENCE.md`
- Encoded-frame review and media checks: `review/`

Run from the workspace root:

```sh
bun fourier-sdk/node_modules/typescript/bin/tsc -p ad-apple/tsconfig.json
bun fourier-render-engine/src/cli.ts validate ad-apple/main.tsx > ad-apple/review/project-validation.json
bun ad-apple/scripts/check.ts
bun ad-apple/scripts/preview.ts 06
bun fourier-render-engine/src/cli.ts render ad-apple/main.tsx --output ad-apple/output/Mac-mini-M6-1080p60.mp4 --overwrite --crf 17 --preset medium --dom-pages 1 --frame-concurrency 1
python3 ad-apple/scripts/verify-media.py
```

Blender regeneration and font subsetting:

```sh
blender --background --python ad-apple/scripts/import-official-model.py
python3 ad-apple/scripts/subset-fonts.py
```

Font subsetting reads the installed Apple San Francisco font and the existing Fourier-ad Heiti collection. It writes small local WOFF subsets; adding copy requires rerunning the script. Runtime assets do not make network requests. Local Chromium and Blender require a host environment in which their native sandbox and graphics services can start.

The two supplied YouTube pages were identified, but playback and transcript retrieval were unavailable in this session. The film is an original interpretation of the requested direction and the verified Apple product content; it does not contain reference-film footage.

## Website material revision

The front/rear callouts now use 6 px round-ended leaders, about 64–77 px long. Dimension endpoints also use short, bold marks. The rear camera follows an exterior orbit instead of interpolating through the enclosure.

Official website images now supply the creative media strips, three display workflows and display hardware, thermal view, iPhone Mirroring and local-AI scene. A four-second ending montage switches Productivity → Creativity → STEM → Gaming → Coding using all ten official gallery images. The enclosure is a single unanimated image layer: its pixels remain identical across all five phases, while the desk, peripherals and applications switch.

The original first cut remains in `output/v1/`. Source URLs, original file hashes and all downloaded assets are retained in `assets/official/sources.json`. `review/official-model-conversion.json` records conversion integrity; `review/ending-product-lock.json` verifies the fixed ending product.

If Chromium context creation fails during a batch render, `python3 ad-apple/scripts/render-scenes.py` renders the same independent Scenes through the same Fourier engine in separate processes. It temporarily isolates one Scene in the root entrypoint, restores the full entrypoint in `finally`, and warms the normal render cache. Run the standard full-film render afterward to assemble the final 75-second output.

## Faster rhythm and handwriting revision

The main narrative is now 62 seconds (previously 72); the 3D camera timing is scaled with the revised scene durations. The five official workflows switch every 0.7 seconds with the Mac mini fixed. Two independent scenes follow: the SDK example handwriting effect writes `ALL IN` / `MAC mini`, then the exact requested attribution appears: `this video` / `完全由 Fourier Harness + GPT6` / `独立完成`. Total: 75 seconds, 4500 frames.

The ending is composed by `templates/ending/main.tsx`; its three scenes remain independently editable and previewable. This keeps the root at 18 render-module declarations within the existing compiler queue. The original engine limits are unchanged. The SDK example snapshot and font are local; provenance is in `review/handwriting-source.json`.

The previous uploaded revision and its manifest/acceptance record are retained in `output/v2/`; previous editable source is archived in `review/v2-source-snapshot.zip`.
