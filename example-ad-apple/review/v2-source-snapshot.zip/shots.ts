export const SHOTS = [
 {id:'01-outline',seconds:4},{id:'02-object',seconds:4},{id:'03-footprint',seconds:4},
 {id:'04-silicon',seconds:5},{id:'05-cpu',seconds:4},{id:'06-gpu',seconds:5},
 {id:'07-neural',seconds:5},{id:'08-memory',seconds:4},{id:'09-bandwidth',seconds:4},
 {id:'10-media',seconds:5},{id:'11-front',seconds:4},{id:'12-back',seconds:4},
 {id:'13-wireless',seconds:5},{id:'14-thermal',seconds:4},{id:'15-displays',seconds:4},
 {id:'16-continuity',seconds:5},{id:'17-create',seconds:2},{id:'18-signature',seconds:8},
] as const;
