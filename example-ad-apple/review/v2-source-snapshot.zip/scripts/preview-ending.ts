import { openArtifact } from '@fourier-video/sdk/testing';
import { resolve } from 'node:path';
const root=resolve(import.meta.dir,'..');
const fixture=await openArtifact(resolve(root,'scenes/18-signature/Visual.tsx'), {sourceRoot:resolve(root,'..'),resourceRoots:[resolve(root,'..')]});
try {
 const times=[.6,2,3.3,4.7,6.4,7.9];
 const results=[];
 for (let i=0;i<times.length;i++) {
  const frame=await fixture.renderFrame({frame:Math.round(times[i]!*60)});
  await Bun.write(resolve(root,`review/ending-phase-${i}.png`),frame.png);
  results.push({time:times[i],sha256:frame.sha256});
 }
 await fixture.renderFrame({frame:36});
 const again=await fixture.renderFrame({frame:384});
 if(again.sha256!==results[4]!.sha256)throw new Error('Ending must be deterministic after arbitrary seek');
 await Bun.write(resolve(root,'review/ending-preview.json'),JSON.stringify({phases:results,deterministic:true},null,2));
 console.log('PASS: all five ending phases and deterministic reverse seeking');
} finally { await fixture.close(); }
