"""Probe and decode the delivered file, then generate review sheets from encoded pixels."""
from pathlib import Path
import subprocess,json,hashlib,re
from PIL import Image,ImageDraw
import numpy as np

root=Path(__file__).resolve().parent.parent
video=root/'output/Mac-mini-M6-1080p60.mp4'
review=root/'review'
def run(args):
 return subprocess.run(args,check=True,capture_output=True,text=True)
probe=json.loads(run(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(video)]).stdout)
v=next(s for s in probe['streams'] if s['codec_type']=='video')
assert (v['width'],v['height'],v['r_frame_rate'],v['codec_name'],v['pix_fmt'])==(1920,1080,'60/1','h264','yuv420p')
assert int(v['nb_frames'])==4800
assert abs(float(v['duration'])-80)<.001
decode=run(['ffmpeg','-v','error','-i',str(video),'-f','null','-'])
assert not decode.stderr.strip(),decode.stderr
pixels=subprocess.run(['ffmpeg','-v','error','-i',str(video),'-an','-vf','crop=1920:960:0:0,scale=64:36,fps=15,format=gray','-f','rawvideo','-'],check=True,capture_output=True).stdout
gray=np.frombuffer(pixels,dtype=np.uint8).reshape(-1,64*36)
flat=gray.std(axis=1)<1.3
runs=[];run_start=None
for i,is_flat in enumerate(list(flat)+[False]):
 if is_flat and run_start is None:run_start=i
 if not is_flat and run_start is not None:
  runs.append({'start':round(run_start/15,3),'duration':round((i-run_start)/15,3)})
  run_start=None
(review/'flat-frame-analysis.json').write_text(json.dumps({'samplingFps':15,'definition':'Top 960px grayscale standard deviation below 1.3','runs':runs},indent=2))
audio=[s for s in probe['streams'] if s['codec_type']=='audio']
audio_result='No audio stream'
if audio:
 log=run(['ffmpeg','-hide_banner','-i',str(video),'-vn','-af','volumedetect,silencedetect=noise=-80dB:d=79','-f','null','-']).stderr
 (review/'audio-verification.log').write_text(log)
 maximum=float(re.search(r'max_volume: ([-\d.]+)',log).group(1))
 durations=[float(x) for x in re.findall(r'silence_duration: ([\d.]+)',log)]
 assert maximum<=-80 and durations and max(durations)>=79.9
 audio_result=f'Silent AAC: maximum {maximum} dB; {max(durations):.3f} s continuous silence'

shots=re.findall(r"id:\s*'([^']+)',\s*seconds:\s*(\d+)",(root/'shots.ts').read_text())
def frame(t,path):
 run(['ffmpeg','-v','error','-ss',str(t),'-i',str(video),'-frames:v','1','-update','1','-y',str(path)])
def sheet(items,out,cols=3,w=640,h=360):
 canvas=Image.new('RGB',(cols*w,((len(items)+cols-1)//cols)*(h+36)),'#e5e5e7');draw=ImageDraw.Draw(canvas)
 for i,(path,label) in enumerate(items):
  x=i%cols*w;y=i//cols*(h+36)
  im=Image.open(path).convert('RGB');im.thumbnail((w,h));canvas.paste(im,(x,y));draw.text((x+14,y+h+11),label,fill='#222222')
 canvas.save(out,quality=94)
items=[];start=0;cuts=[]
for name,seconds in shots:
 seconds=int(seconds);t=start+seconds*.56
 path=review/f'encoded-{name}.jpg';frame(t,path);items.append((path,f'{name}  |  {t:.2f}s'))
 if start:cuts.append(start)
 start+=seconds
sheet(items,review/'storyboard-final.jpg')
joins=[]
for cut in cuts:
 for delta in [-.15,.15]:
  path=review/f'cut-{cut}-{delta}.jpg';frame(cut+delta,path);joins.append((path,f'{cut+delta:.2f}s'))
sheet(joins,review/'transitions-final.jpg',cols=4,w=480,h=270)
hold=[]
for t in [37.35,37.65,38.0]:
 path=review/f'metric-{t}.jpg';frame(t,path);hold.append((path,f'{t:.2f}s'))
sheet(hold,review/'metric-hold-final.jpg',cols=3)
# Inspect each official workflow in the final encoded ending, not just one poster.
ending=[];ending_frames=[]
for i,t in enumerate([72.6,74.0,75.3,76.7,78.4,79.9]):
 path=review/f'encoded-ending-{i}.png';frame(t,path);ending.append((path,f'{t:.2f}s'))
 ending_frames.append(np.array(Image.open(path).convert('RGB')))
sheet(ending,review/'ending-final.jpg',cols=3)
# Compression changes can alter pixels; test that the best matching position remains fixed.
reference=ending_frames[0][365:565,381:581].astype(float)
checks=[]
for i,pixels in enumerate(ending_frames):
 matches=[]
 for dy in range(-3,4):
  for dx in range(-3,4):
   patch=pixels[365+dy:565+dy,381+dx:581+dx].astype(float)
   matches.append((float(np.abs(patch-reference).mean()),dx,dy))
 error,dx,dy=min(matches)
 assert dx==0 and dy==0, f'Ending product shifted in phase {i}: {(dx,dy)}'
 assert error<2, f'Ending product appearance drifted in phase {i}: {error}'
 checks.append({'phase':i,'bestPixelOffset':[dx,dy],'meanPixelError':error})
(review/'ending-encoded-lock.json').write_text(json.dumps({'fixed':True,'samples':checks},indent=2))
frame(78.2,root/'output/Mac-mini-M6-poster.jpg')
digest=hashlib.sha256(video.read_bytes()).hexdigest()
manifest=json.loads(Path(str(video)+'.manifest.json').read_text())
assert manifest['output']['sha256']==digest, 'Manifest hash must match delivered video'
result={'file':str(video),'bytes':video.stat().st_size,'sha256':digest,'width':1920,'height':1080,'fps':60,'duration':80,'frames':4800,'codec':'H.264','pixelFormat':'yuv420p','audio':audio_result,'fullDecode':'PASS','probe':probe}
(review/'media-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in result.items() if k!='probe'},ensure_ascii=False,indent=2))
