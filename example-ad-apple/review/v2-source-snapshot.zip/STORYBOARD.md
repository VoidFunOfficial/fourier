# Mac mini · M6 — 80-second director's treatment

1920 × 1080 · 60 fps · 4800 frames · silent. Independent Fourier Scenes; each scene owns its motion. Root only composes scenes. No chapter headings, feature-card template, narrator, stock footage, simulated AI output, or permanent UI frame.

The visual sentence is a rounded square: pencil outline → aluminium enclosure → chip → core tiles → creative surfaces → ports → desktop → enclosure. Typography labels the thing being seen. Mac mini and M6 are the only product lockups. The palette is paper white, graphite, aluminium; muted peach, mint and periwinkle appear only as creative material. Light is a material property, never a decorative background wash.

| Scene | Duration | Information and visual action | Handoff |
|---|---:|---|---|
| 01 Outline | 4 s | A quick hand-drawn perimeter resolves into the real silver model; macro sweep pulls back. | Same three-quarter silhouette. |
| 02 Object | 4 s | Continuous low orbit over aluminium, Apple inlay and front ports; Mac mini product name. | Rise to top view. |
| 03 Footprint | 4 s | Top view becomes an annotated product drawing; two 5-inch dimensions. | Square contracts to chip size. |
| 04 Silicon | 5 s | Match cut into M6; black package, silver traces, camera tunnels into twelve tiles. | One core fills the frame. |
| 05 CPU | 4 s | Twelve cores assemble in 2/4/6 groups; labels describe super, performance and efficiency cores. | Grid tilts into 3D. |
| 06 GPU | 5 s | A wireframe sculpture becomes a shaded metal object, orbit accelerates around it; 12-core GPU and ray tracing. | Rings flatten into neural nodes. |
| 07 Neural | 5 s | Two 4×4 node matrices snap and communicate; dual 16-core Neural Engine. | Nodes condense into memory blocks. |
| 08 Memory | 4 s | 32 fine slabs collapse into one shared store; CPU and GPU feed the same pool; up to 32GB. | Slabs stretch into data lanes. |
| 09 Bandwidth | 4 s | Silver data lanes race around a stable 170 GB/s endpoint; visible configuration qualification. | Lanes become video strips. |
| 10 Media | 5 s | Official creative desktop imagery unfolds as frames, slits, edit strips and a ProRes film aperture; hardware encode/decode. | Rectangular aperture matches USB-C. |
| 11 Front | 4 s | Macro front-port dolly; two USB-C sockets and 3.5 mm jack identified directly. | Camera swings around right edge. |
| 12 Back | 4 s | Rear connector sweep; three Thunderbolt 4, HDMI and 2.5Gb Ethernet. | Cable stroke becomes radio arc. |
| 13 Wireless | 5 s | Hand-drawn arcs and restrained flat orbital forms; Wi-Fi 7 and Bluetooth 6. | Radio circle becomes underside foot. |
| 14 Thermal | 4 s | Official 3D underside orbit resolves into Apple’s published thermal/airflow image with moving air paths. | Foot rounds out to monitor aperture. |
| 15 Displays | 4 s | Three official Studio Display frames and creative workflows unfold around the official Mac mini model; up to three external displays. | Right panel narrows to an iPhone. |
| 16 Continuity | 5 s | Continuous pan/pullback across the official iPhone Mirroring image; a short bright leader identifies the mirrored phone. | Content expands beyond display. |
| 17 Create | 2 s | Official local-AI workflow on Studio Display; fast pullback and lateral handoff. | Desktop composition match cut. |
| 18 Signature | 8 s | Five official gallery categories: Productivity, Creativity, STEM, Gaming, Coding. Both desktop and application content switch; Mac mini stays at the same position, scale and pixels. | Coding holds with Mac mini / M6 signature. |

## Polish decisions before implementation

- At most one primary claim per composition; secondary labels attach to geometry. No unrelated headlines or mini-headings.
- Accelerated movement is concentrated in approach, transformation and handoff. Important numeric endpoints remain readable for at least 1.4 seconds.
- The graphite line style has tiny deterministic irregularity, not continuous shaking of the product or text.
- Keep product joins as matched camera poses. Use geometric occlusion only where visual spaces change; avoid repeated generic fades.
- Text safe area 110 px horizontally, 80 px vertically. Product may deliberately crop during macro travel.
- Model is imported from the official Apple AR USDZ through Blender, retained as .blend with packed original textures, and exported as glTF/GLB, then animated through FourierCanvas. No Blender-rendered movie substituted for SDK motion.
- Reference videos could not be played in the available browser; transcript retrieval also failed. Only verified titles and user-requested style direction inform the treatment; do not claim frame-level reproduction of those films.

## Revision polish

- Runtime product geometry uses the official 74 meshes, with no decimation or redesigned ports. The former generic port spacing and horizontal USB-C openings are removed.
- Product leaders are 6 px, with round ends, and about 64–77 px long. The dimensions use separated short endpoint strokes rather than long spanning lines.
- The final scene is deliberately locked: 0.00 Productivity, 1.35 Creativity, 2.70 STEM, 4.05 Gaming, 5.40 Coding, holding through 8.00. The rest of the film remains fast moving.
- Fixed product region is compared pixel-for-pixel across six PNG samples, including all five workflows and final hold.
